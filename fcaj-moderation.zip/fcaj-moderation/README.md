# FCAJ — AI Content Moderation (FCJ Workshop)

Hệ thống kiểm duyệt nội dung serverless: phát hiện ngôn từ **tục tĩu / thù ghét** tiếng Việt (+ zero-shot tiếng Anh) bằng **XLM-RoBERTa fine-tune trên ViHSD**, chạy trên **AWS Lambda container**, trọng tài **Bedrock Claude Haiku** khi model không chắc chắn, lịch sử lưu **DynamoDB**, UI **React trên Amplify**.

```
Amplify (React) → API Gateway → Lambda container (ONNX XLM-R)
                                   ├─ conf < 0.7 → Bedrock Claude Haiku
                                   ├─ DynamoDB ModerationHistory
                                   └─ CloudWatch
```

## Trong repo này

| Thư mục | Nội dung | Task (bảng phân công) | Phụ trách |
|---|---|---|---|
| `model/` | Lambda container: Dockerfile, handler inference + ngưỡng confidence, test RIE, script push ECR | Task 6 | Khôi (hỗ trợ: Quốc) |
| `frontend/` | React UI: nhập câu → gọi API → highlight từ tục, nhãn + confidence + nguồn + lịch sử | Task 8 | Quốc (hỗ trợ: Khôi) |
| `HUONG-DAN-DEPLOY.md` | Hướng dẫn deploy từng bước cho phía hạ tầng/backend (task 7, 9) | — | cho Quân + Đức |

Model train ở notebook `train_text_classifier.ipynb` (task 2 + 4, đã Done) — 3 nhãn `CLEAN / OFFENSIVE / HATE`, tiền xử lý trong `model/src/moderation.py` **giữ đồng bộ** với notebook.

## Chạy nhanh

```bash
# 1. Đặt model.onnx + tokenizer.json vào model/artifacts/  (xem model/artifacts/README.md)
# 2. Test local (không cần AWS):
cd model && bash scripts/test_local.sh
# 3. Deploy: làm theo HUONG-DAN-DEPLOY.md
# 4. Frontend dev:
cd frontend && cp .env.example .env && npm install && npm run dev
```

## API

`POST /moderate` — body `{"text": "..."}` →

```json
{
  "requestId": "uuid", "label": "OFFENSIVE", "confidence": 0.93,
  "scores": {"CLEAN": 0.05, "OFFENSIVE": 0.93, "HATE": 0.02},
  "source": "model | bedrock", "bedrockReason": null,
  "flaggedTerms": ["vcl"], "latencyMs": 45.2, "timestamp": "2026-07-21T..."
}
```

Lỗi: `400 EMPTY_INPUT`, `400 TEXT_TOO_LONG` (>2000 ký tự).

`GET /history?limit=20` → `{"items": [...]}` — mới nhất trước (DynamoDB GSI `timestamp-index`).
