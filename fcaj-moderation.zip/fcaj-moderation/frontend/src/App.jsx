import React, { useEffect, useRef, useState } from 'react';
import { moderate, fetchHistory } from './api.js';
import Highlighted from './highlight.jsx';

const LABEL_META = {
  CLEAN: { color: '#16a34a', bg: '#dcfce7', vi: 'Sạch' },
  OFFENSIVE: { color: '#d97706', bg: '#fef3c7', vi: 'Xúc phạm' },
  HATE: { color: '#dc2626', bg: '#fee2e2', vi: 'Thù ghét' },
};

function LabelBadge({ label, confidence }) {
  const meta = LABEL_META[label] || { color: '#64748b', bg: '#f1f5f9', vi: label };
  return (
    <span className="badge" style={{ color: meta.color, background: meta.bg }}>
      {label} · {meta.vi} · {(confidence * 100).toFixed(1)}%
    </span>
  );
}

function SourceTag({ source }) {
  return (
    <span className={`source ${source}`}>
      {source === 'bedrock' ? '⚖️ Bedrock (Claude Haiku)' : '🤖 Model (XLM-R)'}
    </span>
  );
}

function ScoreBar({ scores }) {
  return (
    <div className="scorebar">
      {Object.entries(scores || {}).map(([k, v]) => (
        <div key={k} className="scorerow">
          <span className="scorelabel">{k}</span>
          <div className="track">
            <div
              className="fill"
              style={{ width: `${v * 100}%`, background: (LABEL_META[k] || {}).color }}
            />
          </div>
          <span className="scoreval">{(v * 100).toFixed(1)}%</span>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]); // {text, result?, error?, pending?}
  const [tab, setTab] = useState('chat');
  const [history, setHistory] = useState([]);
  const [historyError, setHistoryError] = useState(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (tab === 'history') loadHistory();
  }, [tab]);

  async function loadHistory() {
    setLoadingHistory(true);
    setHistoryError(null);
    try {
      const data = await fetchHistory(30);
      setHistory(data.items || []);
    } catch (e) {
      setHistoryError(e.message);
    } finally {
      setLoadingHistory(false);
    }
  }

  async function handleSend(e) {
    e?.preventDefault();
    const t = text.trim();
    if (!t) return;
    setText('');
    const idx = messages.length;
    setMessages((m) => [...m, { text: t, pending: true }]);
    try {
      const result = await moderate(t);
      setMessages((m) => m.map((msg, i) => (i === idx ? { text: t, result } : msg)));
    } catch (err) {
      setMessages((m) => m.map((msg, i) => (i === idx ? { text: t, error: err.message } : msg)));
    }
  }

  return (
    <div className="app">
      <header>
        <h1>🛡️ FCAJ</h1>
        <p>AI Content Moderation — phát hiện ngôn từ tục tĩu / thù ghét (vi · en)</p>
        <nav>
          <button className={tab === 'chat' ? 'active' : ''} onClick={() => setTab('chat')}>
            💬 Kiểm duyệt
          </button>
          <button className={tab === 'history' ? 'active' : ''} onClick={() => setTab('history')}>
            🕓 Lịch sử
          </button>
        </nav>
      </header>

      {tab === 'chat' && (
        <main className="chat">
          <div className="messages">
            {messages.length === 0 && (
              <div className="empty">
                Nhập một câu để kiểm duyệt. Ví dụ: <em>“vcl thế, làm ăn như hạch”</em>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className="msg">
                <div className="bubble">
                  <Highlighted text={m.text} terms={m.result?.flaggedTerms} />
                </div>
                {m.pending && <div className="meta pending">Đang phân tích…</div>}
                {m.error && <div className="meta error">⚠️ {m.error}</div>}
                {m.result && (
                  <div className="meta">
                    <LabelBadge label={m.result.label} confidence={m.result.confidence} />
                    <SourceTag source={m.result.source} />
                    <span className="latency">{m.result.latencyMs} ms</span>
                    {m.result.bedrockReason && (
                      <div className="reason">Lý do (Bedrock): {m.result.bedrockReason}</div>
                    )}
                    <ScoreBar scores={m.result.scores} />
                  </div>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
          <form className="inputrow" onSubmit={handleSend}>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Nhập nội dung cần kiểm duyệt…"
              maxLength={2000}
            />
            <button type="submit" disabled={!text.trim()}>Gửi</button>
          </form>
        </main>
      )}

      {tab === 'history' && (
        <main className="history">
          <div className="historyhead">
            <h2>Lịch sử kiểm duyệt (DynamoDB)</h2>
            <button onClick={loadHistory} disabled={loadingHistory}>
              {loadingHistory ? 'Đang tải…' : '↻ Tải lại'}
            </button>
          </div>
          {historyError && <div className="meta error">⚠️ {historyError}</div>}
          {!historyError && history.length === 0 && !loadingHistory && (
            <div className="empty">Chưa có bản ghi nào.</div>
          )}
          <ul>
            {history.map((h) => (
              <li key={h.requestId}>
                <div className="htext">
                  <Highlighted text={h.text || ''} terms={h.flaggedTerms} />
                </div>
                <div className="meta">
                  <LabelBadge label={h.label} confidence={h.confidence} />
                  <SourceTag source={h.source} />
                  <span className="latency">
                    {h.timestamp ? new Date(h.timestamp).toLocaleString('vi-VN') : ''}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </main>
      )}

      <footer>FCJ Workshop · Amplify → API Gateway → Lambda (XLM-R) → Bedrock → DynamoDB</footer>
    </div>
  );
}
