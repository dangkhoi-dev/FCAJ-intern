// Highlight tu tuc tiu trong cau, dua tren flaggedTerms tra ve tu backend.
// Render <mark> quanh tu vi pham — khong phan biet hoa/thuong.
import React from 'react';

export default function Highlighted({ text, terms }) {
  if (!terms || terms.length === 0) return <>{text}</>;

  const escaped = [...terms]
    .sort((a, b) => b.length - a.length)
    .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const re = new RegExp(`(${escaped.join('|')})`, 'gi');

  const parts = text.split(re);
  return (
    <>
      {parts.map((part, i) =>
        terms.some((t) => t.toLowerCase() === part.toLowerCase()) ? (
          <mark key={i} className="flagged">{part}</mark>
        ) : (
          <React.Fragment key={i}>{part}</React.Fragment>
        )
      )}
    </>
  );
}
