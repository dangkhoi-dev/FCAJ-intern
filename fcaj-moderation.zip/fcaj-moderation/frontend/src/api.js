// Goi API backend. Base URL lay tu .env (VITE_API_URL) — xem .env.example
const API_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

async function request(path, options = {}) {
  if (!API_URL) {
    throw new Error('Chưa cấu hình VITE_API_URL — copy .env.example thành .env và điền URL API Gateway.');
  }
  const res = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || data.error || `HTTP ${res.status}`);
  }
  return data;
}

export function moderate(text) {
  return request('/moderate', { method: 'POST', body: JSON.stringify({ text }) });
}

export function fetchHistory(limit = 20) {
  return request(`/history?limit=${limit}`, { method: 'GET' });
}
