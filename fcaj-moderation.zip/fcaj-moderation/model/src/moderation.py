"""
Core inference: load ONNX INT8 XLM-RoBERTa (fine-tuned tren ViHSD) + tokenizer,
tien xu ly GIONG HET notebook train_text_classifier.ipynb, tra ve nhan + confidence.

Artifacts can co trong MODEL_DIR (mac dinh /var/task/artifacts):
  - model.onnx        (ban INT8 quantized, xuat tu optimum — xem scripts/export_onnx.py)
  - tokenizer.json    (tokenizer fast cua XLM-R, luu bang tokenizer.save_pretrained)
"""

import os
import re
import unicodedata

import numpy as np

LABELS = ["CLEAN", "OFFENSIVE", "HATE"]
MAX_LENGTH = 128  # giong luc train

MODEL_DIR = os.environ.get("MODEL_DIR", "/var/task/artifacts")

# --- Tien xu ly: PHAI giong het clean_text() trong notebook train ---
URL_RE = re.compile(r"https?://\S+|www\.\S+")
MENTION_RE = re.compile(r"@\w+")


def clean_text(t: str) -> str:
    t = unicodedata.normalize("NFC", str(t))
    t = URL_RE.sub(" <URL> ", t)
    t = MENTION_RE.sub(" <USER> ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# --- Wordlist de highlight tu tuc tren UI (khong dung de phan loai) ---
# Phan loai la viec cua model; wordlist chi giup frontend to mau tu vi pham.
BAD_WORDS = [
    # tieng Viet + teencode
    "đm", "dm", "đmm", "vcl", "vl", "cc", "clm", "cl", "đéo", "deo",
    "địt", "dit", "lồn", "lon", "cặc", "cak", "buồi", "đĩ", "di~",
    "óc chó", "oc cho", "ngu", "chó", "súc vật", "suc vat", "rác rưởi",
    "mất dạy", "mat day", "khốn nạn", "khon nan", "cút", "chết đi",
    # tieng Anh
    "fuck", "fucking", "shit", "bitch", "asshole", "idiot", "stupid",
    "moron", "bastard", "dumb", "retard", "trash", "loser",
]
_BAD_RE = re.compile(
    r"(?<!\w)(" + "|".join(re.escape(w) for w in sorted(BAD_WORDS, key=len, reverse=True)) + r")(?!\w)",
    re.IGNORECASE,
)


def find_flagged_terms(text: str):
    """Tra ve danh sach tu vi pham (unique, giu thu tu xuat hien)."""
    seen, out = set(), []
    for m in _BAD_RE.finditer(unicodedata.normalize("NFC", text)):
        w = m.group(0).lower()
        if w not in seen:
            seen.add(w)
            out.append(w)
    return out


# --- Lazy-load model + tokenizer (1 lan / container, tai dung cho warm start) ---
_session = None
_tokenizer = None


def _load():
    global _session, _tokenizer
    if _session is None:
        import onnxruntime as ort
        from tokenizers import Tokenizer

        model_path = os.path.join(MODEL_DIR, "model.onnx")
        if not os.path.exists(model_path):
            # optimum quantize co the dat ten model_quantized.onnx
            alt = os.path.join(MODEL_DIR, "model_quantized.onnx")
            if os.path.exists(alt):
                model_path = alt
            else:
                raise FileNotFoundError(
                    f"Khong tim thay model.onnx trong {MODEL_DIR}. "
                    "Copy artifacts tu notebook train vao model/artifacts/ truoc khi build image."
                )
        so = ort.SessionOptions()
        so.intra_op_num_threads = int(os.environ.get("ORT_THREADS", "4"))
        _session = ort.InferenceSession(model_path, so, providers=["CPUExecutionProvider"])

        _tokenizer = Tokenizer.from_file(os.path.join(MODEL_DIR, "tokenizer.json"))
        _tokenizer.enable_truncation(max_length=MAX_LENGTH)
    return _session, _tokenizer


def _softmax(x):
    x = x - np.max(x)
    e = np.exp(x)
    return e / e.sum()


def classify(text: str):
    """Chay inference. Tra ve (label, confidence, scores_dict)."""
    session, tokenizer = _load()
    enc = tokenizer.encode(clean_text(text))
    input_ids = np.array([enc.ids], dtype=np.int64)
    attention_mask = np.array([enc.attention_mask], dtype=np.int64)

    feeds = {"input_ids": input_ids, "attention_mask": attention_mask}
    # mot so ban export chi nhan input co trong graph
    valid = {i.name for i in session.get_inputs()}
    feeds = {k: v for k, v in feeds.items() if k in valid}

    logits = session.run(None, feeds)[0][0]
    probs = _softmax(logits.astype(np.float64))

    idx = int(np.argmax(probs))
    scores = {LABELS[i]: round(float(p), 4) for i, p in enumerate(probs)}
    return LABELS[idx], float(probs[idx]), scores
