"""
Ghi / doc lich su kiem duyet tren DynamoDB table ModerationHistory.

Schema (khop task 5 trong bang phan cong):
  - PK: requestId (S)
  - GSI "timestamp-index": gsi1pk (S, hang so "HISTORY") + gsi1sk (S, ISO timestamp)
    -> query lich su moi nhat bang 1 Query, ScanIndexForward=False

Env:
  TABLE_NAME  (mac dinh ModerationHistory) — de trong "" de tat ghi lich su
  GSI_NAME    (mac dinh timestamp-index)
"""

import os
from datetime import datetime, timezone
from decimal import Decimal

TABLE_NAME = os.environ.get("TABLE_NAME", "ModerationHistory")
GSI_NAME = os.environ.get("GSI_NAME", "timestamp-index")

_table = None


def _get_table():
    global _table
    if _table is None:
        import boto3

        _table = boto3.resource("dynamodb").Table(TABLE_NAME)
    return _table


def put_record(request_id, text, label, confidence, source, scores, flagged_terms, latency_ms):
    if not TABLE_NAME:
        return None
    ts = datetime.now(timezone.utc).isoformat()
    item = {
        "requestId": request_id,
        "gsi1pk": "HISTORY",
        "gsi1sk": ts,
        "timestamp": ts,
        "text": text[:500],  # khong luu qua dai
        "label": label,
        "confidence": Decimal(str(round(confidence, 4))),
        "source": source,
        "scores": {k: Decimal(str(v)) for k, v in scores.items()},
        "flaggedTerms": flagged_terms,
        "latencyMs": Decimal(str(round(latency_ms, 1))),
    }
    _get_table().put_item(Item=item)
    return ts


def get_recent(limit=20):
    if not TABLE_NAME:
        return []
    from boto3.dynamodb.conditions import Key

    resp = _get_table().query(
        IndexName=GSI_NAME,
        KeyConditionExpression=Key("gsi1pk").eq("HISTORY"),
        ScanIndexForward=False,  # moi nhat truoc
        Limit=max(1, min(int(limit), 100)),
    )
    items = []
    for it in resp.get("Items", []):
        items.append(
            {
                "requestId": it.get("requestId"),
                "timestamp": it.get("timestamp"),
                "text": it.get("text"),
                "label": it.get("label"),
                "confidence": float(it.get("confidence", 0)),
                "source": it.get("source"),
                "flaggedTerms": it.get("flaggedTerms", []),
            }
        )
    return items
