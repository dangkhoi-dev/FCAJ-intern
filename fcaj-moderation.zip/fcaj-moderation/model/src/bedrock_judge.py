"""
Trong tai Bedrock (Claude Haiku): duoc goi khi model chinh co confidence < nguong.
Tra ve (label, confidence, raw_text) hoac raise exception (handler se fallback ve model).
"""

import json
import os

LABELS = {"CLEAN", "OFFENSIVE", "HATE"}

BEDROCK_MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0")
BEDROCK_REGION = os.environ.get("BEDROCK_REGION", os.environ.get("AWS_REGION", "us-east-1"))

_client = None

PROMPT_TEMPLATE = """Bạn là hệ thống kiểm duyệt nội dung. Phân loại đoạn văn bản sau vào đúng MỘT nhãn:
- CLEAN: bình thường, không vi phạm
- OFFENSIVE: xúc phạm, tục tĩu nhắm vào cá nhân
- HATE: thù ghét nhắm vào nhóm người (giới tính, tôn giáo, vùng miền, sắc tộc...)

Văn bản (giữa thẻ <text>): <text>{text}</text>

Chỉ trả về JSON đúng định dạng: {{"label": "...", "confidence": 0.xx, "reason": "ngắn gọn 1 câu"}}"""


def _get_client():
    global _client
    if _client is None:
        import boto3

        _client = boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)
    return _client


def judge(text: str):
    """Goi Claude Haiku phan xu. Raise neu loi — handler chiu trach nhiem fallback."""
    client = _get_client()
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 200,
        "temperature": 0,
        "messages": [
            {"role": "user", "content": PROMPT_TEMPLATE.format(text=text[:1000])}
        ],
    }
    resp = client.invoke_model(modelId=BEDROCK_MODEL_ID, body=json.dumps(body))
    payload = json.loads(resp["body"].read())
    raw = payload["content"][0]["text"].strip()

    # Claude co the boc JSON trong ```...``` — lay phan {...} dau tien
    start, end = raw.find("{"), raw.rfind("}")
    parsed = json.loads(raw[start : end + 1])

    label = str(parsed.get("label", "")).upper()
    if label not in LABELS:
        raise ValueError(f"Bedrock tra nhan la: {label!r}")
    confidence = float(parsed.get("confidence", 0.9))
    return label, min(max(confidence, 0.0), 1.0), parsed.get("reason", "")
