"""
Lambda handler — FCAJ AI Content Moderation.

Routes (API Gateway proxy integration, ho tro ca REST v1 va HTTP API v2 event):
  POST /moderate          body: {"text": "..."}  -> phan loai CLEAN/OFFENSIVE/HATE
  GET  /history?limit=20  -> lich su kiem duyet tu DynamoDB (moi nhat truoc)

Luong xu ly /moderate:
  1. Validate input (rong -> 400, qua dai -> 400)
  2. Model ONNX (XLM-R fine-tuned ViHSD) -> label + confidence
  3. Neu confidence < CONFIDENCE_THRESHOLD (0.7) va ENABLE_BEDROCK=true
     -> goi Bedrock Claude Haiku lam trong tai, source="bedrock"
  4. Tim flagged terms (wordlist) de UI highlight
  5. Ghi DynamoDB (neu TABLE_NAME khac rong)

Env vars (tat ca co default hop ly):
  MODEL_DIR=/var/task/artifacts   CONFIDENCE_THRESHOLD=0.7
  ENABLE_BEDROCK=true             BEDROCK_MODEL_ID=anthropic.claude-3-haiku-20240307-v1:0
  TABLE_NAME=ModerationHistory    GSI_NAME=timestamp-index
  MAX_TEXT_LEN=2000               CORS_ORIGIN=*
"""

import json
import os
import time
import uuid

import moderation

CONFIDENCE_THRESHOLD = float(os.environ.get("CONFIDENCE_THRESHOLD", "0.7"))
ENABLE_BEDROCK = os.environ.get("ENABLE_BEDROCK", "true").lower() == "true"
MAX_TEXT_LEN = int(os.environ.get("MAX_TEXT_LEN", "2000"))
CORS_ORIGIN = os.environ.get("CORS_ORIGIN", "*")

CORS_HEADERS = {
    "Access-Control-Allow-Origin": CORS_ORIGIN,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Content-Type": "application/json",
}


def _response(status, body):
    return {
        "statusCode": status,
        "headers": CORS_HEADERS,
        "body": json.dumps(body, ensure_ascii=False),
    }


def _parse_event(event):
    """Chuan hoa event API Gateway v1 (REST) / v2 (HTTP API) -> (method, path, body, query)."""
    if "requestContext" in event and "http" in event.get("requestContext", {}):
        # HTTP API v2
        method = event["requestContext"]["http"]["method"]
        path = event.get("rawPath", "/")
    else:
        # REST API v1 (hoac test event don gian)
        method = event.get("httpMethod", "POST")
        path = event.get("path", "/moderate")

    body = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        import base64

        body = base64.b64decode(body).decode("utf-8")
    try:
        body = json.loads(body)
    except (json.JSONDecodeError, TypeError):
        body = {}

    query = event.get("queryStringParameters") or {}
    return method.upper(), path, body, query


def _moderate(body):
    text = body.get("text")
    if text is None or not str(text).strip():
        return _response(400, {"error": "EMPTY_INPUT", "message": "Vui lòng nhập nội dung cần kiểm duyệt."})
    text = str(text)
    if len(text) > MAX_TEXT_LEN:
        return _response(
            400,
            {
                "error": "TEXT_TOO_LONG",
                "message": f"Nội dung vượt quá {MAX_TEXT_LEN} ký tự (hiện tại: {len(text)}).",
            },
        )

    t0 = time.perf_counter()
    label, confidence, scores = moderation.classify(text)
    source = "model"
    bedrock_reason = None

    if confidence < CONFIDENCE_THRESHOLD and ENABLE_BEDROCK:
        try:
            import bedrock_judge

            label, confidence, bedrock_reason = bedrock_judge.judge(text)
            source = "bedrock"
        except Exception as e:  # Bedrock loi -> giu ket qua model, khong lam gay request
            print(f"[WARN] Bedrock fallback loi, dung ket qua model: {e}")

    flagged_terms = moderation.find_flagged_terms(text)
    latency_ms = (time.perf_counter() - t0) * 1000
    request_id = str(uuid.uuid4())

    timestamp = None
    try:
        import history

        timestamp = history.put_record(
            request_id, text, label, confidence, source, scores, flagged_terms, latency_ms
        )
    except Exception as e:  # DynamoDB loi -> van tra ket qua
        print(f"[WARN] Ghi DynamoDB loi: {e}")

    return _response(
        200,
        {
            "requestId": request_id,
            "label": label,
            "confidence": round(confidence, 4),
            "scores": scores,
            "source": source,
            "bedrockReason": bedrock_reason,
            "flaggedTerms": flagged_terms,
            "latencyMs": round(latency_ms, 1),
            "timestamp": timestamp,
        },
    )


def _history(query):
    try:
        import history

        items = history.get_recent(limit=int(query.get("limit", 20)))
        return _response(200, {"items": items})
    except Exception as e:
        print(f"[ERROR] Doc lich su loi: {e}")
        return _response(500, {"error": "HISTORY_ERROR", "message": str(e)})


def lambda_handler(event, context):
    method, path, body, query = _parse_event(event)

    if method == "OPTIONS":  # CORS preflight
        return _response(200, {})
    if method == "POST" and path.rstrip("/").endswith("/moderate"):
        return _moderate(body)
    if method == "GET" and path.rstrip("/").endswith("/history"):
        return _history(query)

    return _response(404, {"error": "NOT_FOUND", "message": f"Không có route {method} {path}"})
