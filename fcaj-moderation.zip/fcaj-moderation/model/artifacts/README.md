# Model artifacts (KHÔNG commit lên Git)

Đặt vào thư mục này đúng 2 file trước khi build Docker image:

| File | Nguồn |
|---|---|
| `model.onnx` | Bản INT8 xuất từ notebook `train_text_classifier.ipynb` (mục 10 — thư mục `xlmr-vihsd-onnx-int8/`, file tên `model_quantized.onnx` thì đổi tên thành `model.onnx`) |
| `tokenizer.json` | Trong thư mục `xlmr-vihsd-v0/` (đã `tokenizer.save_pretrained`) hoặc `xlmr-vihsd-onnx-int8/` |

Nếu notebook chưa chạy bước ONNX, dùng script chuyển đổi:

```bash
cd model/scripts
pip install "optimum[onnxruntime]" transformers
python export_onnx.py --model_dir /duong/dan/xlmr-vihsd-v0 --out_dir ../artifacts
```

Hoặc tải từ S3 (bucket model artifacts của task 5 — Đức đã tạo):

```bash
aws s3 cp s3://<bucket-model-artifacts>/xlmr-vihsd/model.onnx      artifacts/model.onnx
aws s3 cp s3://<bucket-model-artifacts>/xlmr-vihsd/tokenizer.json  artifacts/tokenizer.json
```
