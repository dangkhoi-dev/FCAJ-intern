"""
Xuat model da fine-tune (./xlmr-vihsd-v0 tu notebook) sang ONNX + quantize INT8,
va gom dung 2 file can cho container vao model/artifacts/.

Chay o may co model (Colab/Kaggle sau khi train, hoac local sau khi tai tu S3):
    pip install "optimum[onnxruntime]" transformers
    python export_onnx.py --model_dir ./xlmr-vihsd-v0 --out_dir ../artifacts

Ket qua trong --out_dir:
    model.onnx      (INT8, ~280MB)
    tokenizer.json
"""

import argparse
import os
import shutil


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_dir", default="./xlmr-vihsd-v0", help="Thu muc model HF da fine-tune")
    ap.add_argument("--out_dir", default="../artifacts", help="Noi dat model.onnx + tokenizer.json")
    args = ap.parse_args()

    from optimum.onnxruntime import ORTModelForSequenceClassification, ORTQuantizer
    from optimum.onnxruntime.configuration import AutoQuantizationConfig
    from transformers import AutoTokenizer

    os.makedirs(args.out_dir, exist_ok=True)
    tmp_onnx = os.path.join(args.out_dir, "_tmp_onnx")
    tmp_int8 = os.path.join(args.out_dir, "_tmp_int8")

    print("[1/3] Export ONNX...")
    ort_model = ORTModelForSequenceClassification.from_pretrained(args.model_dir, export=True)
    ort_model.save_pretrained(tmp_onnx)

    print("[2/3] Quantize INT8 (dynamic, AVX2)...")
    quantizer = ORTQuantizer.from_pretrained(tmp_onnx)
    qconfig = AutoQuantizationConfig.avx2(is_static=False)
    quantizer.quantize(save_dir=tmp_int8, quantization_config=qconfig)

    print("[3/3] Gom artifacts...")
    # optimum dat ten model_quantized.onnx -> doi thanh model.onnx
    src = os.path.join(tmp_int8, "model_quantized.onnx")
    if not os.path.exists(src):
        src = os.path.join(tmp_int8, "model.onnx")
    shutil.copy(src, os.path.join(args.out_dir, "model.onnx"))

    tok = AutoTokenizer.from_pretrained(args.model_dir)
    tok.save_pretrained(tmp_onnx)  # dam bao co tokenizer.json (fast)
    shutil.copy(os.path.join(tmp_onnx, "tokenizer.json"), os.path.join(args.out_dir, "tokenizer.json"))

    shutil.rmtree(tmp_onnx, ignore_errors=True)
    shutil.rmtree(tmp_int8, ignore_errors=True)
    print(f"XONG. Kiem tra {args.out_dir}: model.onnx + tokenizer.json")


if __name__ == "__main__":
    main()
