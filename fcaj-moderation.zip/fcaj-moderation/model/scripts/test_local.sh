#!/usr/bin/env bash
# Test local bang Lambda RIE (Runtime Interface Emulator — co san trong base image AWS).
# Chay tu thu muc model/:  bash scripts/test_local.sh
set -euo pipefail

IMAGE=${IMAGE:-fcaj-moderation:local}

echo "==> Build image..."
docker build -t "$IMAGE" .

echo "==> Chay container (RIE lang nghe cong 9000)..."
docker rm -f fcaj-rie 2>/dev/null || true
# ENABLE_BEDROCK=false + TABLE_NAME rong -> test thuan model, khong can AWS credentials
docker run -d --name fcaj-rie -p 9000:8080 \
  -e ENABLE_BEDROCK=false -e TABLE_NAME= "$IMAGE"
sleep 3

invoke() {
  curl -s -X POST "http://localhost:9000/2015-03-31/functions/function/invocations" -d "$1"
  echo
}

echo "==> Test 1: cau sach"
invoke "$(cat events/clean.json)"

echo "==> Test 2: cau tuc tiu (teencode)"
invoke "$(cat events/offensive.json)"

echo "==> Test 3: input rong (mong doi 400)"
invoke "$(cat events/empty.json)"

echo "==> Test 4: input qua dai (mong doi 400)"
invoke "$(cat events/too_long.json)"

echo "==> Xong. Dung container: docker rm -f fcaj-rie"
