#!/usr/bin/env bash
# Build + push image len ECR. Chay tu thu muc model/:
#   AWS_ACCOUNT_ID=123456789012 AWS_REGION=ap-southeast-1 bash scripts/push_ecr.sh
set -euo pipefail

: "${AWS_ACCOUNT_ID:?Can set AWS_ACCOUNT_ID (12 so)}"
AWS_REGION=${AWS_REGION:-ap-southeast-1}
REPO=${REPO:-fcaj-moderation}
TAG=${TAG:-v1}
URI="$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$REPO"

echo "==> Tao repo ECR neu chua co..."
aws ecr describe-repositories --repository-names "$REPO" --region "$AWS_REGION" >/dev/null 2>&1 \
  || aws ecr create-repository --repository-name "$REPO" --region "$AWS_REGION" \
       --image-scanning-configuration scanOnPush=true >/dev/null

echo "==> Login ECR..."
aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

echo "==> Build (x86_64 — khop voi Lambda architecture mac dinh)..."
docker build --platform linux/amd64 -t "$URI:$TAG" .

echo "==> Push..."
docker push "$URI:$TAG"

echo "==> XONG: $URI:$TAG"
echo "    Dua URI nay cho buoc tao Lambda (xem HUONG-DAN-DEPLOY.md muc 4)."
